﻿using System;

namespace ejercicios_arrays_clases
{
    class Program
    {
        static void Main(string[] args)
        {
            MediaAritmetica();

            NumerosReales();

            MesesDelAgno();

            NumeroMayor();

            NombresDigitados();

            NombreSeparadoConEspacio();

            PersonasAltura();
        }

        private static void MediaAritmetica()
        {
            Console.WriteLine("Favor entrar 4 numeros (presionar ENTER al digitar cada numero).");

            //Arreglo para almacenar los numeros digitados
            int[] numeros = new int[4];

            //Recorrer el arreglo agregandole cada numero introducido por el usuario
            for(int i=0; i < 4; i++)
            {
                Console.Write(i+1 + ") Numero: ");
                numeros[i] = int.Parse(Console.ReadLine());
            }

            //Recorrer el arreglo para calcular la media aritmetica
            float mediaAritmetica = 0;

            for(int i=0; i < 4; i++)
            {
                mediaAritmetica += numeros[i];
            }

            //Resultado final de la media aritmetica
            mediaAritmetica = mediaAritmetica / 4;
            Console.WriteLine("Media Aritmetica: " + mediaAritmetica);
            
            //Imprimir los valores
            Console.WriteLine("Valores introducidos por el usuario:");
            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine(numeros[i]);
            }
        }

        private static void NumerosReales()
        {
            Console.WriteLine("Introducir 5 numeros reales");

            //Arreglo para almacenar los numeros digitados
            float[] numeros = new float[5];

            //Recorrer el arreglo agregandole cada numero introducido por el usuario
            for (int i = 0; i < 5; i++)
            {
                Console.Write(i + 1 + ") Numero: ");
                numeros[i] = float.Parse(Console.ReadLine());
            }

            //Imprimir los valores de forma inversa
            Console.WriteLine("Valores introducidos por el usuario de forma inversa:");
            for (int i = 4; i >= 0; i--)
            {
                Console.WriteLine(numeros[i]);
            }
        }

        private static void MesesDelAgno()
        {
            Console.WriteLine("Meses del año");

            //Arreglo para almacenar los dias de los meses
            int[] dias = new int[] { 31,28,31,30,31,30,31,31,30,31,30,31 };

            Console.Write("Favor introducir un mes (en numero): ");
            int mes = int.Parse(Console.ReadLine());

            if (mes > 12 || mes < 1)
            {
                Console.WriteLine("El mes digitado no es valido");
            }
            else
            {
                Console.WriteLine("El mes digitado tiene: " + dias[mes-1]);
            }
        }

        private static void NumeroMayor()
        {
            Console.WriteLine("Introducir 10");

            //Arreglo para almacenar los numeros digitados
            float[] numeros = new float[10];

            //Recorrer el arreglo agregandole cada numero introducido por el usuario
            for (int i = 0; i < 10; i++)
            {
                Console.Write(i + 1 + ") Numero: ");
                numeros[i] = float.Parse(Console.ReadLine());
            }

            //Buscar el numero mayor
            float mayor = 0;

            for (int i = 0; i < 10; i++)
            {
                if(numeros[i] > mayor)
                    mayor = numeros[i];
            }

            Console.Write("El numero mayor es: " + mayor);
        }

        private static void NombresDigitados()
        {
            Console.WriteLine("Introducir nombres");

            //Arreglo para almacenar los nombres digitados
            string[] nombres = new string[100];

            //Recorrer el arreglo agregandole cada nombre introducido por el usuario
            for (int i = 0; i < 100; i++)
            {
                Console.Write(i + 1 + ") Nombre: ");
                string nombre = Console.ReadLine();

                //Validar que se digito algo
                if (string.IsNullOrEmpty(nombre) == false)
                    nombres[i] = nombre;
                else
                    break;
            }

            //Imprimir nombres digitados
            Console.WriteLine("Nombres digitados:");
            for (int i = 0; i < 100; i++)
            {
                if (string.IsNullOrEmpty(nombres[i]) == false)
                    Console.WriteLine( i + 1 + ") " + nombres[i]);
            }
        }

        private static void NombreSeparadoConEspacio()
        {
            Console.Write("Introducir nombre: ");
            string nombre = Console.ReadLine();

            Console.WriteLine();

            foreach(char c in nombre)
            {
                Console.Write(c);
                Console.Write(" ");
            }

            Console.WriteLine();
        }

        private static void PersonasAltura()
        {
            Console.WriteLine("Introducir 5 distintas alturas de personas");

            //Arreglo para almacenar los numeros digitados
            float[] numeros = new float[5];

            //Recorrer el arreglo agregandole cada numero introducido por el usuario
            for (int i = 0; i < 5; i++)
            {
                Console.Write(i + 1 + ") Altura: ");
                numeros[i] = float.Parse(Console.ReadLine());
            }

            float promedio = 0;
            for (int i = 0; i < 5; i++)
            {
                promedio += numeros[i];
            }
            //Resultado final del promedio
            promedio = promedio / 5;

            //Imprimir los que son mas altos que el valor promedio
            Console.WriteLine("Por encima del promedio:");
            for (int i = 0; i < 5; i++)
            {
                if (numeros[i] > promedio)
                    Console.WriteLine(numeros[i]);
            }

            //Imprimir los que son mas bajos que el valor promedio
            Console.WriteLine("Por debajo del promedio:");
            for (int i = 0; i < 5; i++)
            {
                if (numeros[i] < promedio)
                    Console.WriteLine(numeros[i]);
            }
        }
    }
}
